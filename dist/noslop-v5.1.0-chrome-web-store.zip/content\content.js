/**
 * NoSlop - Content Script (Orchestrator v5.1)
 * Ultra-low CPU/RAM via IntersectionObserver lazy viewport evaluation.
 * Clean, non-intrusive action buttons near video titles.
 * Frictionless 1-click slop reporting with zero watch-page playback disruption.
 * Verified creator safety and instant placeholder unhiding.
 */

(() => {
  'use strict';

  console.log('%c[NoSlop 5.1]%c Active with Lazy Viewport Evaluation & Creator Safety.', 'color: #f43f5e; font-weight: bold', 'color: #94a3b8');

  const SENSITIVITY_THRESHOLDS = {
    aggressive: 0.35,
    balanced: 0.50,
    conservative: 0.65
  };

  const CARD_SELECTORS = [
    'ytd-rich-item-renderer',
    'ytd-video-renderer',
    'ytd-compact-video-renderer',
    'ytd-grid-video-renderer',
    'ytd-playlist-renderer',
    'ytd-playlist-video-renderer',
    'ytd-reel-item-renderer',
    'ytd-reel-video-renderer',
    'ytd-radio-renderer',
    'ytd-movie-renderer',
    'ytd-channel-renderer',
    'ytd-notification-renderer',
    'ytm-rich-item-renderer',
    'ytm-video-with-context-renderer',
    'ytm-compact-video-renderer',
    'ytm-reel-item-renderer',
    'ytm-shorts-lockup-view-model',
    'ytm-shorts-lockup-view-model-v2',
    'yt-lockup-view-model',
    '.yt-lockup-view-model',
    'yt-shorts-lockup-view-model',
    '.ytShortsLockupViewModelHost',
    '.ytGridShelfViewModelGridShelfItem'
  ];
  const CARD_SELECTOR_TEXT = CARD_SELECTORS.join(', ');
  const CARD_WRAPPER_SELECTOR = 'ytd-rich-item-renderer, ytm-rich-item-renderer, yt-lockup-view-model, .yt-lockup-view-model, ytm-shorts-lockup-view-model, ytm-shorts-lockup-view-model-v2, yt-shorts-lockup-view-model, .ytShortsLockupViewModelHost, .ytGridShelfViewModelGridShelfItem';

  const SHELF_SELECTOR = 'ytd-rich-shelf-renderer, ytd-reel-shelf-renderer, ytm-reel-shelf-renderer, grid-shelf-view-model';

  let settings = {
    enabled: true,
    engineScoring: true,        // Engine 1: Multi-signal heuristic & semantic scoring
    sensitivity: "balanced",
    engineThumbnails: false,    // Engine 2: DISABLED by default to protect human creators using AI art
    whitelistVerified: true,    // Protects verified human creators (StarTalk, Kurzgesagt, etc.)
    engineCommunity: true,      // Engine 3: Community & curated blocklist consensus
    engineAudioScript: true,    // Engine 4: Script perplexity & repetition analysis
    blockSyntheticDisclosures: true,
    blockShorts: false,         // FALSE by default: only AI slop shorts are blocked, human shorts stay
    placeholderMode: false,     // Clean AdBlock style (default)
    blockedChannels: [],
    allowedChannels: [],
    remoteChannels: [],
    remoteVideos: []
  };

  let evaluationGeneration = 0;
  const processingCards = new WeakSet();
  const hydrationRetryCounts = new WeakMap();
  const originalCardStyles = new WeakMap();
  const BLOCK_STYLE_PROPERTIES = ['display', 'height', 'min-height', 'margin', 'padding', 'overflow'];
  let tabCountSyncTimeout = null;

  function initializeEngines() {
    window.NoSlopCommunity?.init(
      settings.blockedChannels,
      settings.engineCommunity !== false ? settings.remoteChannels : [],
      settings.remoteVideos || [],
      settings.allowedChannels
    );
  }

  function syncTabCount() {
    tabCountSyncTimeout = null;
    const count = document.querySelectorAll('[data-noslop-status="blocked"]').length;
    try {
      chrome.runtime.sendMessage({ action: 'tabCountSync', count });
    } catch {}
  }

  function scheduleTabCountSync() {
    if (tabCountSyncTimeout) clearTimeout(tabCountSyncTimeout);
    tabCountSyncTimeout = setTimeout(syncTabCount, 50);
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'getTabCount') {
      sendResponse({ count: document.querySelectorAll('[data-noslop-status="blocked"]').length });
    }
  });

  function loadSettings() {
    chrome.storage.sync.get(null, (syncData) => {
      if (chrome.runtime.lastError) {
        console.warn('[NoSlop] Could not read sync settings:', chrome.runtime.lastError.message);
      } else if (syncData && Object.keys(syncData).length > 0) {
        settings = { ...settings, ...syncData };
      }
      // Load 46k+ community blocklist from local storage
      chrome.storage.local.get(['remoteChannels', 'remoteVideos', 'learningExamples'], (localData) => {
        if (localData?.remoteChannels) {
          settings.remoteChannels = localData.remoteChannels;
        }
        if (localData?.remoteVideos) {
          settings.remoteVideos = localData.remoteVideos;
        }
        initializeEngines();
        window.NoSlopSemantic?.setExamples?.(localData?.learningExamples || []);

        resetAllCards({ preserveRevealed: true });
        scanFeed();
      });
    });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync') {
      if (!Object.keys(changes).some(key => key in settings)) return;
      let masterToggledOff = false;
      for (const [key, change] of Object.entries(changes)) {
        settings[key] = change.newValue;
        if (key === 'enabled' && change.newValue === false) {
          masterToggledOff = true;
        }
      }
      initializeEngines();

      if (masterToggledOff) {
        resetAllCards();
      } else {
        // Re-evaluate existing cards when any rule or engine changes. Leaving
        // the old status in place makes toggles appear broken until navigation.
        resetAllCards({ preserveRevealed: true });
        scanFeed();
      }
    } else if (area === 'local') {
      if (!changes.remoteChannels && !changes.remoteVideos && !changes.learningExamples) return;
      if (changes.remoteChannels) {
        settings.remoteChannels = changes.remoteChannels.newValue || [];
      }
      if (changes.remoteVideos) settings.remoteVideos = changes.remoteVideos.newValue || [];
      initializeEngines();
      if (changes.learningExamples) window.NoSlopSemantic?.setExamples?.(changes.learningExamples.newValue || []);
      resetAllCards({ preserveRevealed: true });
      scanFeed();
    }
  });

  function cardPlaceholder(rootCard) {
    const previous = rootCard?.previousElementSibling;
    return previous?.classList.contains('noslop-placeholder') ? previous : null;
  }

  function clearCardVisualState(rootCard) {
    rootCard.classList.remove('noslop-hidden', 'noslop-revealed', 'noslop-collapsed');
    for (const [property, value, priority] of originalCardStyles.get(rootCard) || []) {
      if (value) rootCard.style.setProperty(property, value, priority);
      else rootCard.style.removeProperty(property);
    }
    originalCardStyles.delete(rootCard);
    cardPlaceholder(rootCard)?.remove();
  }

  function resetAllCards({ preserveRevealed = false } = {}) {
    evaluationGeneration++;
    document.querySelectorAll('[data-noslop-sig]').forEach((el) => {
      const isRevealed = el.dataset.noslopStatus === 'revealed' || el.classList.contains('noslop-revealed');
      if (preserveRevealed && isRevealed) return;

      cardObserver.unobserve(el);
      el.removeAttribute('data-noslop-sig');
      el.removeAttribute('data-noslop-status');
      el.removeAttribute('data-noslop-reason');
      el.removeAttribute('data-noslop-observed');
      el.removeAttribute('data-noslop-revealed-video');
      clearCardVisualState(el);
      hydrationRetryCounts.delete(el);
    });

    if (!preserveRevealed) {
      document.querySelectorAll('.noslop-title-actions').forEach((el) => el.remove());
    }

    scheduleTabCountSync();
  }

  function findRootCard(el) {
    let card = el.closest(CARD_SELECTOR_TEXT) || el;
    if (card.matches('ytd-rich-item-renderer, ytm-rich-item-renderer') && card.querySelector(SHELF_SELECTOR)) return null;
    let outer = card.parentElement?.closest(CARD_WRAPPER_SELECTOR);
    while (outer && !outer.querySelector(SHELF_SELECTOR)) {
      card = outer;
      outer = card.parentElement?.closest(CARD_WRAPPER_SELECTOR);
    }
    return card;
  }

  function metadataSignature(meta) {
    return JSON.stringify([meta.videoId, meta.title, meta.fullUntruncatedTitle, meta.channelName,
      meta.channelHref, meta.snippet, meta.badgeText, meta.isVerified, meta.hasAiInfoButton, meta.isShort,
      meta.thumbnailImg?.currentSrc || meta.thumbnailImg?.src]);
  }

  function extractMetadata(rootCard) {
    const titleCandidates = [];
    let fullUntruncatedTitle = '';

    const titleEl = rootCard.querySelector(
      '#video-title, #video-title-link, a.yt-lockup-metadata-view-model-wiz__title, a.yt-lockup-metadata-view-model__title, .ytShortsLockupViewModelHostMetadataTitle, h3 a, h3, ytd-reel-player-header-renderer #title, #overlay h2, .yt-core-attributed-string'
    );

    if (titleEl) {
      if (titleEl.textContent) titleCandidates.push(titleEl.textContent);
      const attrTitle = titleEl.getAttribute('title');
      if (attrTitle) {
        titleCandidates.push(attrTitle);
        fullUntruncatedTitle = attrTitle;
      }
      const attrAria = titleEl.getAttribute('aria-label');
      if (attrAria && !titleCandidates.length) {
        titleCandidates.push(attrAria);
        if (!fullUntruncatedTitle) fullUntruncatedTitle = attrAria;
      }
    }

    const watchLink = rootCard.querySelector('a[href*="/watch?v="], a[href*="/shorts/"]');
    let videoId = '';
    if (watchLink) {
      const linkTitle = watchLink.getAttribute('title');
      if (linkTitle) {
        titleCandidates.push(linkTitle);
        if (!fullUntruncatedTitle) fullUntruncatedTitle = linkTitle;
      }
      const linkAria = watchLink.getAttribute('aria-label');
      if (linkAria && !titleCandidates.length) {
        titleCandidates.push(linkAria);
        if (!fullUntruncatedTitle) fullUntruncatedTitle = linkAria;
      }
      const href = watchLink.getAttribute('href') || '';
      const watchMatch = href.match(/[?&]v=([^&]+)/);
      const shortsMatch = href.match(/\/shorts\/([^/?#]+)/);
      if (watchMatch) videoId = watchMatch[1];
      else if (shortsMatch) videoId = shortsMatch[1];
    }

    const title = (fullUntruncatedTitle || titleCandidates[0] || '').replace(/\s+/g, ' ').trim();

    // 2. Channel Name
    const channelEl = rootCard.querySelector(
      'ytd-channel-name, #channel-name, #text.ytd-channel-name, .yt-lockup-metadata-view-model-wiz__metadata a, .yt-lockup-metadata-view-model__metadata a, #byline-container a, #channel-info, ytd-reel-player-header-renderer a, a[href*="/@"], a[href*="/channel/"]'
    );
    const channelLink = channelEl?.matches?.('a[href*="/@"], a[href*="/channel/"]')
      ? channelEl
      : channelEl?.querySelector?.('a[href*="/@"], a[href*="/channel/"]');
    const channelName = (channelLink?.textContent || channelEl?.textContent || '').replace(/\s+/g, ' ').trim();
    const channelHref = channelLink?.getAttribute('href') || channelEl?.getAttribute('href') || '';
    const isVerified = Boolean(rootCard.querySelector(
      '[aria-label="Verified" i], .badge-style-type-verified, .badge-style-type-verified-artist'
    ));

    // 3. Description Snippet (Search Results)
    const snippetEl = rootCard.querySelector(
      '#description-text, .metadata-snippet-container, .metadata-snippet-text, yt-formatted-string.metadata-snippet-text, #snippet, yt-formatted-string[class*="snippet"], ytd-video-renderer .metadata-snippet-container span, ytd-playlist-renderer #description'
    );
    const snippet = (snippetEl?.textContent || '').replace(/\s+/g, ' ').trim();

    // 4. Badges
    const badgeText = Array.from(rootCard.querySelectorAll(
      'ytd-badge-supported-renderer, yt-badge-view-model, .ytBadgeViewModelHost, .badge-shape'
    )).map(b => b.textContent).join(' ');

    const cardText = (rootCard.textContent || '').replace(/\s+/g, ' ').trim();
    const hasAiInfoButton = Boolean(rootCard.querySelector(
      'button[aria-label="AI content" i], button[aria-label*="AI-generated" i], button[aria-label*="Altered or synthetic" i], [role="button"][aria-label="AI content" i], yt-badge-view-model[aria-label*="AI-generated" i], .ytBadgeViewModelHost[aria-label*="AI-generated" i]'
    )) || /(?:^|\s)(?:AI content|AI-generated|Altered or synthetic content)(?:$|\s)/i.test(badgeText);

    const isShort = Boolean(
      rootCard.matches('ytd-reel-item-renderer, ytd-reel-video-renderer, ytm-reel-item-renderer, ytm-shorts-lockup-view-model, ytm-shorts-lockup-view-model-v2, yt-shorts-lockup-view-model, .ytShortsLockupViewModelHost') ||
      rootCard.closest('ytd-reel-shelf-renderer, ytd-rich-shelf-renderer[is-shorts]') ||
      rootCard.querySelector('a[href*="/shorts/"]')
    );

    const thumbnailImg = rootCard.querySelector('#thumbnail img, ytd-thumbnail img, yt-image img');

    return {
      title,
      fullUntruncatedTitle,
      videoId,
      channelName,
      channelHref,
      channelId: channelHref.match(/\/channel\/(UC[a-zA-Z0-9_-]{22})(?:[/?#]|$)/)?.[1] || '',
      isVerified,
      snippet,
      scriptText: snippet,
      badgeText,
      cardText,
      hasAiInfoButton,
      isShort,
      thumbnailImg
    };
  }

  function requestVideoMetadata(videoId) {
    return new Promise(resolve => {
      try {
        chrome.runtime.sendMessage({ action: 'getVideoMetadata', videoId }, result => {
          if (chrome.runtime.lastError) resolve(null);
          else resolve(result);
        });
      } catch { resolve(null); }
    });
  }

  async function enrichVideoMetadata(meta) {
    if (!/^[a-zA-Z0-9_-]{11}$/.test(meta.videoId || '')) return null;
    const metadata = await requestVideoMetadata(meta.videoId);
    if (metadata?.videoId !== meta.videoId) return null;
    return {
      ...meta,
      title: metadata.title || meta.title,
      fullUntruncatedTitle: metadata.title || meta.fullUntruncatedTitle,
      channelName: metadata.channelName || meta.channelName,
      channelId: metadata.channelId,
      snippet: metadata.description || meta.snippet,
      scriptText: metadata.description || meta.scriptText
    };
  }

  async function evaluateVideo(meta, { enrich = true } = {}) {
    if (!settings.enabled) return { isBlocked: false, score: 0, reason: 'Disabled' };
    const baseThreshold = SENSITIVITY_THRESHOLDS[settings.sensitivity] || 0.50;
    const threshold = (meta.isShort && settings.blockShorts)
      ? Math.min(baseThreshold, 0.40)
      : baseThreshold;
    let textScore = 0;

    const channelIdHref = meta.channelId ? `/channel/${meta.channelId}` : '';
    if (window.NoSlopCommunity?.isChannelAllowed?.(meta.channelName, meta.channelHref) ||
        (channelIdHref && window.NoSlopCommunity?.isChannelAllowed?.('', channelIdHref))) {
      return { isBlocked: false, score: 0.0, reason: 'User Allowlist' };
    }

    const hasIdAllowEntry = (Array.isArray(settings.allowedChannels) ? settings.allowedChannels : []).some(value =>
      typeof value === 'string' && /(?:^|\/channel\/)UC[a-zA-Z0-9_-]{22}(?:[/?#]|$)/.test(value));
    if (enrich && !channelIdHref && hasIdAllowEntry) {
      const enriched = await enrichVideoMetadata(meta);
      if (enriched) return evaluateVideo(enriched, { enrich: false });
      enrich = false;
    }
    if (window.NoSlopCommunity?.isUserChannelBlocked?.(meta.channelName, meta.channelHref) ||
        (channelIdHref && window.NoSlopCommunity?.isUserChannelBlocked?.('', channelIdHref))) {
      return { isBlocked: true, score: 1.0, reason: 'User Blacklist' };
    }
    if (settings.engineScoring !== false && settings.blockSyntheticDisclosures !== false && meta.hasAiInfoButton) {
      return { isBlocked: true, score: 1.0, reason: 'YouTube synthetic-media disclosure' };
    }

    // 1. Engine 3: Community & Curated Blocklist Consensus (Exact indexed lookup)
    if (settings.engineCommunity !== false && window.NoSlopCommunity) {
      if (meta.videoId && window.NoSlopCommunity.isVideoBlocked?.(meta.videoId)) {
        return { isBlocked: true, score: 1.0, reason: 'Community Blocklisted Video ID' };
      }

      const commCheck = window.NoSlopCommunity.isChannelBlocked(meta.channelName, meta.channelHref);
      if (commCheck?.blocked) {
        return { isBlocked: true, score: 1.0, reason: commCheck.source || 'Community Blocklist' };
      }
      if (channelIdHref && window.NoSlopCommunity.isChannelBlocked('', channelIdHref).blocked) {
        return { isBlocked: true, score: 1, reason: 'Community Blocklist ID' };
      }
    }

    // 2. Engine 1: Multi-Signal Heuristic Scoring
    if (settings.engineScoring !== false && window.NoSlopScoring) {
      const scoreFn = (typeof window.NoSlopScoring.calculateScore === 'function')
        ? window.NoSlopScoring.calculateScore
        : (typeof window.NoSlopScoring.calculate === 'function' ? window.NoSlopScoring.calculate : null);

      if (scoreFn) {
        const scoringResult = scoreFn(meta, {
          sensitivityThreshold: threshold,
          whitelistVerified: settings.whitelistVerified !== false,
          blockSyntheticDisclosures: settings.blockSyntheticDisclosures !== false
        });
        textScore = scoringResult?.score || 0;

        // If AI Shorts filter is toggled, enforce stricter sensitivity (0.40) on shorts, but NEVER blanket block clean human videos
        if (scoringResult && scoringResult.score >= threshold) {
          return {
            isBlocked: true,
            score: scoringResult.score,
            reason: (scoringResult.reasons && scoringResult.reasons.join(' + ')) || 'High AI Probability'
          };
        }
      }
    }

    const protectedCreator = settings.whitelistVerified !== false && meta.isVerified;

    // Generic script-pattern analysis. The analyzer is
    // intentionally metadata-only here; opening an AudioContext for every
    // feed card would interfere with playback and waste significant CPU.
    if (!protectedCreator && settings.engineAudioScript !== false && window.NoSlopAudioScript?.analyzeScript) {
      const scriptResult = window.NoSlopAudioScript.analyzeScript(meta.scriptText || '');
      if (textScore >= 0.25 && scriptResult?.score >= Math.max(threshold, 0.65)) {
        return {
          isBlocked: true,
          score: scriptResult.score,
          reason: scriptResult.reason || 'Statistical script pattern'
        };
      }
    }

    // 4. Engine 2: Thumbnail Vision Texture Scanner (Disabled by default to protect human creators)
    if (!protectedCreator && settings.engineThumbnails && window.NoSlopVision && meta.thumbnailImg) {
      const visionResult = await window.NoSlopVision.scanThumbnail(meta.thumbnailImg);
      if (visionResult?.score >= Math.max(threshold, 0.70)) {
        return {
          isBlocked: true,
          score: visionResult.score,
          reason: `AI Thumbnail Vision (${visionResult.reason})`
        };
      }
    }

    if (enrich && /^[a-zA-Z0-9_-]{11}$/.test(meta.videoId || '') &&
        (settings.engineScoring !== false || settings.engineCommunity !== false)) {
      const enriched = await enrichVideoMetadata(meta);
      if (enriched) return evaluateVideo(enriched, { enrich: false });
    }

    return { isBlocked: false, score: 0.0, reason: protectedCreator ? 'Verified creator protected' : 'Clean' };
  }

  function applyBlock(rootCard, meta, reason = 'AI Content') {
    if (rootCard.dataset.noslopStatus === 'revealed' || rootCard.classList.contains('noslop-revealed')) {
      return;
    }

    rootCard.dataset.noslopStatus = 'blocked';
    rootCard.dataset.noslopReason = reason;
    if (!originalCardStyles.has(rootCard)) {
      originalCardStyles.set(rootCard, BLOCK_STYLE_PROPERTIES.map(property =>
        [property, rootCard.style.getPropertyValue(property), rootCard.style.getPropertyPriority(property)]));
    }

    if (settings.placeholderMode) {
      rootCard.classList.add('noslop-hidden');
      rootCard.style.setProperty('display', 'none', 'important');

      let placeholder = cardPlaceholder(rootCard);
      if (!placeholder) {
        placeholder = document.createElement('div');
        placeholder.className = 'noslop-placeholder';

        const info = document.createElement('div');
        info.className = 'noslop-placeholder-info';

        const badge = document.createElement('span');
        badge.className = 'noslop-placeholder-badge';
        badge.textContent = 'AI Hidden';

        const reasonEl = document.createElement('span');
        reasonEl.className = 'noslop-placeholder-reason';
        reasonEl.title = reason;
        reasonEl.textContent = `${(meta.title || 'AI Video').slice(0, 48)}...`;

        const revealBtn = document.createElement('button');
        revealBtn.type = 'button';
        revealBtn.className = 'noslop-reveal-btn';
        revealBtn.textContent = 'Show';

        info.append(badge, reasonEl);
        placeholder.append(info, revealBtn);

        revealBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          e.preventDefault();
          clearCardVisualState(rootCard);
          rootCard.classList.add('noslop-revealed');
          rootCard.dataset.noslopStatus = 'revealed';
          rootCard.dataset.noslopRevealedVideo = meta.videoId || meta.title;
          scheduleTabCountSync();
        });

        rootCard.parentNode?.insertBefore(placeholder, rootCard);
      }
    } else {
      cardPlaceholder(rootCard)?.remove();

      rootCard.classList.add('noslop-hidden');
      rootCard.style.setProperty('display', 'none', 'important');
      rootCard.style.setProperty('height', '0px', 'important');
      rootCard.style.setProperty('min-height', '0px', 'important');
      rootCard.style.setProperty('margin', '0px', 'important');
      rootCard.style.setProperty('padding', '0px', 'important');
      rootCard.style.setProperty('overflow', 'hidden', 'important');
    }

    if (!rootCard.dataset.noslopCounted) {
      rootCard.dataset.noslopCounted = 'true';
      try {
        chrome.runtime.sendMessage({ action: 'videoBlocked', count: 1 });
      } catch {}
    }

    scheduleTabCountSync();
  }

  /**
   * Action buttons: Placed unobtrusively near title/3-dots, 1-Click Auto-Block & Report
   */
  function injectQuickBlockAction(rootCard, meta) {
    if (!rootCard || rootCard.querySelector('.noslop-title-actions')) return;

    // Prefer YouTube's #menu (next to 3-dots), fallback to title container or metadata
    const targetMenu = rootCard.querySelector('#menu, ytd-menu-renderer, #menu-container');
    const titleContainer = rootCard.querySelector('#title-wrapper, #meta, #details, .yt-lockup-metadata-view-model-wiz__metadata');
    const container = targetMenu || titleContainer;
    if (!container) return;

    const actionContainer = document.createElement('div');
    actionContainer.className = 'noslop-title-actions';

    // 1-Click Auto Slop Report & Block Button (Instant vanish + auto blacklist + auto queue)
    const reportBtn = document.createElement('button');
    reportBtn.className = 'noslop-title-btn noslop-report-btn';
    reportBtn.type = 'button';
    reportBtn.title = `1-Click: Auto-block channel "${meta.channelName || 'this channel'}" and report as AI slop`;
    reportBtn.innerHTML = `
      <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none">
        <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path>
        <line x1="4" y1="22" x2="4" y2="15"></line>
      </svg>
      <span>⚑ Slop</span>
    `;

    reportBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();

      const freshMeta = extractMetadata(rootCard);
      const chName = freshMeta.channelName || meta.channelName || 'Reported Channel';

      // Immediately hide the card
      applyBlock(rootCard, freshMeta, 'User Reported AI Slop');

      if (chName && chName !== 'Reported Channel') {
        addChannelToBlocklist(freshMeta.channelHref || chName);
      }

      // Auto-save to report queue
      chrome.storage.local.get(['reportedSlopQueue'], (data) => {
        const queue = data.reportedSlopQueue || [];
        const report = {
          channelName: chName,
          channelHref: freshMeta.channelHref || meta.channelHref,
          videoTitle: freshMeta.fullUntruncatedTitle || freshMeta.title || meta.title,
          videoId: freshMeta.videoId || meta.videoId,
          timestamp: new Date().toISOString()
        };
        const reportKey = report.videoId || `${report.channelHref}|${report.videoTitle}`;
        const withoutDuplicate = queue.filter(item =>
          (item.videoId || `${item.channelHref}|${item.videoTitle}`) !== reportKey
        );
        withoutDuplicate.push(report);
        chrome.storage.local.set({ reportedSlopQueue: withoutDuplicate.slice(-500) });

        chrome.storage.local.get(['learningExamples'], (learningData) => {
          const examples = Array.isArray(learningData.learningExamples) ? learningData.learningExamples : [];
          examples.push({
            label: 1,
            text: [report.videoTitle, report.channelName].filter(Boolean).join(' '),
            timestamp: report.timestamp
          });
          const bounded = examples.slice(-2000);
          chrome.storage.local.set({ learningExamples: bounded });
        });
      });

      try {
        chrome.runtime.sendMessage({
          action: 'openReport',
          channelName: chName,
          channelHref: freshMeta.channelHref || meta.channelHref,
          videoTitle: freshMeta.fullUntruncatedTitle || freshMeta.title || meta.title,
          videoId: freshMeta.videoId || meta.videoId
        });
      } catch {}

      showToast(`Blocked & Reported "${chName}" as AI slop`);
    });

    actionContainer.appendChild(reportBtn);

    if (targetMenu) {
      targetMenu.insertBefore(actionContainer, targetMenu.firstChild);
    } else {
      container.appendChild(actionContainer);
    }
  }

  function addChannelToBlocklist(channelName) {
    chrome.storage.sync.get('blockedChannels', (data) => {
      const list = data.blockedChannels || [];
      if (!list.includes(channelName)) {
        list.push(channelName);
        chrome.storage.sync.set({ blockedChannels: list }, () => {
          settings.blockedChannels = list;
          initializeEngines();
          scanFeed();
        });
      }
    });
  }

  function showToast(message) {
    const existing = document.querySelector('.noslop-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'noslop-toast';
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.style.transition = 'opacity 0.3s ease';
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 300);
    }, 2500);
  }

  /**
   * Process an individual card that has entered the viewport or hydrated
   */
  function retryHydratingCard(rootCard) {
    const attempts = hydrationRetryCounts.get(rootCard) || 0;
    if (attempts >= 10) return false;

    hydrationRetryCounts.set(rootCard, attempts + 1);
    setTimeout(() => {
      if (!rootCard.isConnected || rootCard.dataset.noslopStatus === 'revealed') return;
      rootCard.removeAttribute('data-noslop-sig');
      processCard(rootCard);
    }, 150);
    return true;
  }

  async function processCard(rootCard) {
    if (!settings.enabled || !rootCard || !rootCard.isConnected) return;
    const meta = extractMetadata(rootCard);
    if (rootCard.dataset.noslopStatus === 'revealed' || rootCard.classList.contains('noslop-revealed')) {
      if (rootCard.dataset.noslopRevealedVideo === (meta.videoId || meta.title)) return;
      clearCardVisualState(rootCard);
      rootCard.removeAttribute('data-noslop-status');
      rootCard.removeAttribute('data-noslop-revealed-video');
    }
    if (!meta.title || meta.title.length < 2) {
      retryHydratingCard(rootCard);
      return;
    }

    // Do not make a final decision while Polymer/Wiz is still hydrating the
    // channel metadata. This prevents a title-only false positive from being
    // permanently applied before the channel whitelist/blocklist is visible.
    if (!meta.channelName && !meta.channelHref && retryHydratingCard(rootCard)) {
      return;
    }
    hydrationRetryCounts.delete(rootCard);

    const sig = metadataSignature(meta);
    if (rootCard.dataset.noslopSig === sig &&
        (rootCard.dataset.noslopStatus === 'clean' || rootCard.dataset.noslopStatus === 'blocked')) return;

    if (processingCards.has(rootCard)) return;
    processingCards.add(rootCard);
    const generationAtStart = evaluationGeneration;

    const previousVideo = rootCard.dataset.noslopVideo;
    const currentVideo = meta.videoId || meta.title;
    if (previousVideo !== currentVideo) rootCard.removeAttribute('data-noslop-counted');
    rootCard.dataset.noslopVideo = currentVideo;
    rootCard.dataset.noslopSig = sig;

    try {
      const evalResult = await evaluateVideo(meta);

      // Thumbnail analysis is asynchronous. If YouTube recycled this node
      // while it was running, discard the stale result and evaluate the new
      // metadata instead of blocking the wrong video.
      if (!rootCard.isConnected) return;
      if (generationAtStart !== evaluationGeneration) {
        rootCard.removeAttribute('data-noslop-sig');
        rootCard.removeAttribute('data-noslop-status');
        clearCardVisualState(rootCard);
        setTimeout(() => processCard(rootCard), 0);
        return;
      }
      const latestMeta = extractMetadata(rootCard);
      const latestSig = metadataSignature(latestMeta);
      if (latestSig !== sig) {
        rootCard.removeAttribute('data-noslop-sig');
        rootCard.removeAttribute('data-noslop-status');
        clearCardVisualState(rootCard);
        setTimeout(() => processCard(rootCard), 0);
        return;
      }

      if (evalResult.isBlocked) {
        applyBlock(rootCard, meta, evalResult.reason);
      } else {
        clearCardVisualState(rootCard);
        rootCard.dataset.noslopStatus = 'clean';
        rootCard.removeAttribute('data-noslop-reason');
        if (meta.channelName) {
          injectQuickBlockAction(rootCard, meta);
        }
        scheduleTabCountSync();
      }
    } finally {
      processingCards.delete(rootCard);
    }
  }

  function isElementInViewport(el) {
    if (!el || !el.getBoundingClientRect) return false;
    const rect = el.getBoundingClientRect();
    const vh = window.innerHeight || document.documentElement.clientHeight;
    return rect.bottom >= -200 && rect.top <= vh + 300;
  }

  /**
   * Ultra-low CPU IntersectionObserver: Only evaluates cards as they approach viewport
   */
  const cardObserver = new IntersectionObserver((entries) => {
    for (let i = 0; i < entries.length; i++) {
      const entry = entries[i];
      if (entry.isIntersecting) {
        const rootCard = entry.target;
        cardObserver.unobserve(rootCard);
        rootCard.removeAttribute('data-noslop-observed');
        processCard(rootCard);
      }
    }
  }, {
    root: null,
    rootMargin: '300px 0px 300px 0px',
    threshold: 0
  });

  /**
   * Main scan loop: Immediately processes viewport cards; queues offscreen cards
   */
  function scanFeed() {
    if (!settings.enabled) {
      scheduleTabCountSync();
      return;
    }

    const elements = document.querySelectorAll(CARD_SELECTOR_TEXT);

    const roots = new Set();
    for (let i = 0; i < elements.length; i++) {
      const rootCard = findRootCard(elements[i]);
      if (!rootCard || !rootCard.isConnected || roots.has(rootCard)) continue;
      roots.add(rootCard);

      if (isElementInViewport(rootCard)) {
        processCard(rootCard);
      } else if (!rootCard.dataset.noslopObserved) {
        rootCard.dataset.noslopObserved = 'true';
        cardObserver.observe(rootCard);
      }
    }

    scheduleTabCountSync();
  }

  // DOM Mutation Observer (debounced, ignores NoSlop's own nodes to prevent feedback loops)
  let debounceTimeout = null;
  const observer = new MutationObserver((mutations) => {
    let hasExternalNodes = false;
    for (let i = 0; i < mutations.length; i++) {
      const m = mutations[i];
      if (m.type === 'childList') {
        for (let j = 0; j < m.addedNodes.length; j++) {
          const n = m.addedNodes[j];
          if (n.nodeType === 3 && m.target.closest?.(CARD_SELECTOR_TEXT) &&
              !m.target.closest('.noslop-title-actions, .noslop-placeholder, .noslop-toast')) {
            hasExternalNodes = true;
            break;
          }
          if (n.nodeType === 1) {
            const cl = n.classList;
            if (cl && (cl.contains('noslop-title-actions') || cl.contains('noslop-placeholder') || cl.contains('noslop-toast') || cl.contains('noslop-hidden') || cl.contains('noslop-revealed'))) {
              continue;
            }
            hasExternalNodes = true;
            break;
          }
        }
        if (!hasExternalNodes) {
          for (let j = 0; j < m.removedNodes.length; j++) {
            const n = m.removedNodes[j];
            if (n.nodeType === 1 && (
              n.matches?.(CARD_SELECTOR_TEXT) ||
              n.querySelector?.('[data-noslop-status="blocked"]')
            )) {
              hasExternalNodes = true;
              break;
            }
          }
        }
      }
      if (m.type === 'characterData') {
        const parent = m.target.parentElement;
        if (parent?.closest(CARD_SELECTOR_TEXT) &&
            !parent.closest('.noslop-title-actions, .noslop-placeholder, .noslop-toast')) {
          hasExternalNodes = true;
        }
      }
      if (m.type === 'attributes') {
        const target = m.target;
        if (target.closest?.(CARD_SELECTOR_TEXT) &&
            !target.closest('.noslop-title-actions, .noslop-placeholder, .noslop-toast')) {
          hasExternalNodes = true;
        }
      }
      if (hasExternalNodes) break;
    }
    if (!hasExternalNodes) return;

    if (debounceTimeout) clearTimeout(debounceTimeout);
    debounceTimeout = setTimeout(scanFeed, 150);
  });

  if (document.body) {
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: ['title', 'aria-label', 'href']
    });
    scanFeed();
  } else {
    document.addEventListener('DOMContentLoaded', () => {
      observer.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: true,
        attributeFilter: ['title', 'aria-label', 'href']
      });
      scanFeed();
    });
  }

  // Handle YouTube SPA page transitions & dynamic feed updates
  window.addEventListener('yt-navigate-finish', () => {
    resetAllCards();
    setTimeout(scanFeed, 100);
    setTimeout(scanFeed, 500);
    setTimeout(scanFeed, 1200);
  });

  window.addEventListener('yt-page-data-updated', () => {
    setTimeout(scanFeed, 100);
    setTimeout(scanFeed, 500);
  });

  window.addEventListener('spfdone', scanFeed);
  window.addEventListener('popstate', () => {
    resetAllCards();
    setTimeout(scanFeed, 150);
  });

  loadSettings();
})();
